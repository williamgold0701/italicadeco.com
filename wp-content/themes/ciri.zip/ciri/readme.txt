 === Ciri ===
Contributors: LA Studio
Requires at least: WordPress 5.0
Tested up to: WordPress 6.0.2, WooCommerce 6.8.2
Version: 1.0.1
Tags: catalog, ceramics, craftsman, decor, elementor, furniture, furniture catalog, furniture portfolio, furniture shop, furniture store, home decor, interior decoration, lighting, woocommerce, woodworker
documentation: http://docs.la-studioweb.com/ciri/

== Description ==

Ciri - Furniture & Interior WooCommerce Theme

* Mobile-first, Responsive Layout
* Custom Colors
* Custom Header
* Social Links
* Mega Menu
* Post Formats

== Installation ==

1. Navigate to Appearance → Themes in your WordPress admin dashboard.
2. Click the Add New button at the top of the page then go for the Theme Upload option.
3. For the file upload, pick Theme Files / ciri.zip in the theme package downloaded from ThemeForest and click Install Now.
4. Click Activate once the upload has finished.

== Copyright ==

Copyright 2015-2022 La-StudioWeb.com

------------ Version 1.0.1 [December 03, 2022]  ------------
# Compatible with Elementor 3.9
# Compatible with WooCommerce 7.1

------------ Version 1.0 Release [September 11, 2022]  ------------
* Release

Initial release